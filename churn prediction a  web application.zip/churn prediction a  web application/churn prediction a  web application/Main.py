import os
import pandas as pd
import numpy as np
from flask import Flask, render_template
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import GaussianNB
from sklearn.linear_model import RidgeClassifier
from sklearn.ensemble import RandomForestClassifier, VotingClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, classification_report, confusion_matrix
from sklearn.preprocessing import LabelEncoder
import seaborn as sns
import matplotlib.pyplot as plt
import matplotlib.ticker as mtick
import joblib
import base64
from io import BytesIO
from catboost import CatBoostClassifier
from lightgbm import LGBMClassifier
from sklearn.utils import resample
from imblearn.over_sampling import SMOTE
from cleanlab.classification import CleanLearning


app = Flask(__name__)

# Paths
DATA_PATH = 'dataset/WA_Fn-UseC_-Telco-Customer-Churn.csv'
TEST_DATA_PATH = 'dataset/test.csv'
MODEL_DIR = 'models'
os.makedirs(MODEL_DIR, exist_ok=True)

# Load and preprocess data
def load_data():
    df = pd.read_csv(DATA_PATH)
    return df

def preprocess_data(df):
    df_processed = df.copy()
    df_processed['TotalCharges'] = pd.to_numeric(df_processed['TotalCharges'], errors='coerce')
    df_processed['TotalCharges'].fillna(df_processed['TotalCharges'].median(), inplace=True)
    
    le = LabelEncoder()
    categorical_cols = df_processed.select_dtypes(include=['object']).columns.drop(['customerID', 'Churn'])
    for col in categorical_cols:
        df_processed[col] = le.fit_transform(df_processed[col])
    
    df_processed['Churn'] = le.fit_transform(df_processed['Churn'])
    
    X = df_processed.drop(['customerID', 'Churn'], axis=1)
    y = df_processed['Churn']
    return X, y, df_processed

# Perform EDA
def perform_eda(df):
    plots = []
    

    
    # 2. Customers with Dependents and Partners
    df2 = pd.melt(df, id_vars=['customerID'], value_vars=['Dependents', 'Partner'])
    df3 = df2.groupby(['variable', 'value']).count().unstack()
    df3 = df3 * 100 / len(df)
    colors = ['#4D3425', '#E4512B']
    ax = df3.loc[:, 'customerID'].plot.bar(stacked=True, color=colors, figsize=(8, 6), rot=0, width=0.2)
    ax.yaxis.set_major_formatter(mtick.PercentFormatter())
    ax.set_ylabel('% Customers', size=14)
    ax.set_xlabel('')
    ax.set_title('% Customers with Dependents and Partners', size=14)
    ax.legend(loc='center', prop={'size': 14})
    for p in ax.patches:
        width, height = p.get_width(), p.get_height()
        x, y = p.get_xy()
        ax.annotate('{:.0f}%'.format(height), (p.get_x() + 0.25 * width, p.get_y() + 0.4 * height),
                    color='white', weight='bold', size=14)
    buf = BytesIO()
    plt.savefig(buf, format='png')
    buf.seek(0)
    plots.append(base64.b64encode(buf.getvalue()).decode('utf-8'))
    plt.close()
    
    # 3. Tenure Distribution
    plt.figure(figsize=(8, 6))
    ax = sns.histplot(df['tenure'], bins=int(180/5), color='darkblue', edgecolor='black')
    ax.set_ylabel('# of Customers')
    ax.set_xlabel('Tenure (months)')
    ax.set_title('# of Customers by their Tenure')
    buf = BytesIO()
    plt.savefig(buf, format='png')
    buf.seek(0)
    plots.append(base64.b64encode(buf.getvalue()).decode('utf-8'))
    plt.close()
    
    # 4. Service Usage
    services = ['PhoneService', 'MultipleLines', 'InternetService', 'OnlineSecurity',
                'OnlineBackup', 'DeviceProtection', 'TechSupport', 'StreamingTV', 'StreamingMovies']
    fig, axes = plt.subplots(nrows=3, ncols=3, figsize=(15, 12))
    for i, item in enumerate(services):
        if i < 3:
            ax = df[item].value_counts().plot(kind='bar', ax=axes[i, 0], rot=0)
        elif i >= 3 and i < 6:
            ax = df[item].value_counts().plot(kind='bar', ax=axes[i-3, 1], rot=0)
        elif i < 9:
            ax = df[item].value_counts().plot(kind='bar', ax=axes[i-6, 2], rot=0)
        ax.set_title(item)
    plt.tight_layout()
    buf = BytesIO()
    plt.savefig(buf, format='png')
    buf.seek(0)
    plots.append(base64.b64encode(buf.getvalue()).decode('utf-8'))
    plt.close()
    
    return plots

# Train-test split
def split_data(X, y):
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    return X_train, X_test, y_train, y_test

# Generate confusion matrix plot
def generate_cm_plot(y_test, y_pred, model_name):
    cm = confusion_matrix(y_test, y_pred)
    plt.figure(figsize=(6, 4))
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', cbar=False,
                xticklabels=['No', 'Yes'], yticklabels=['No', 'Yes'])
    plt.title(f'Confusion Matrix - {model_name}')
    plt.xlabel('Predicted')
    plt.ylabel('Actual')
    buf = BytesIO()
    plt.savefig(buf, format='png')
    buf.seek(0)
    cm_plot = base64.b64encode(buf.getvalue()).decode('utf-8')
    plt.close()
    return cm_plot

# Train and evaluate models
def train_evaluate_model(model, model_path, X_train, X_test, y_train, y_test, model_name):
    if os.path.exists(model_path):
        clf = joblib.load(model_path)
    else:
        clf = model
        clf.fit(X_train, y_train)
        joblib.dump(clf, model_path)
    
    y_pred = clf.predict(X_test)
    cm_plot = generate_cm_plot(y_test, y_pred, model_name)
    return {
        'Model': model_name,
        'Accuracy': accuracy_score(y_test, y_pred),
        'Precision': precision_score(y_test, y_pred, average='weighted'),
        'Recall': recall_score(y_test, y_pred, average='weighted'),
        'F1': f1_score(y_test, y_pred, average='weighted'),
        'Classification Report': classification_report(y_test, y_pred, target_names=['No', 'Yes']),
        'Confusion Matrix Plot': cm_plot
    }

# Predict on test data
def predict_test_data():
    test_df = pd.read_csv(TEST_DATA_PATH)
    customer_ids = test_df['customerID']
    test_df_processed = test_df.copy()
    
    # Preprocess test data
    test_df_processed = test_df.copy()
    test_df_processed['TotalCharges'] = pd.to_numeric(test_df_processed['TotalCharges'], errors='coerce')
    test_df_processed['TotalCharges'].fillna(test_df_processed['TotalCharges'].median(), inplace=True)
    
    le = LabelEncoder()
    categorical_cols = test_df_processed.select_dtypes(include=['object']).columns.drop('customerID')
    for col in categorical_cols:
        test_df_processed[col] = le.fit_transform(test_df_processed[col])
    
    X_test = test_df_processed.drop('customerID', axis=1)
    
    # Load models
    nb = joblib.load(os.path.join(MODEL_DIR, 'nb_model.pkl'))
    ridge = joblib.load(os.path.join(MODEL_DIR, 'ridge_model.pkl'))
    cascade = joblib.load(os.path.join(MODEL_DIR, 'cascade_model.pkl'))
    
    predictions = {
        'customer_ids': customer_ids.tolist(),
        'Naive Bayes': nb.predict(X_test).tolist(),
        'Ridge Classifier': ridge.predict(X_test).tolist(),
        'Cascade Ensemble': cascade.predict(X_test).tolist(),
        'test_data_html': test_df.to_html(classes='table table-striped', index=False)
    }
    
    return predictions

# Routes
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/dataset')
def dataset():
    df = load_data()
    dataset_html = df.head().to_html(classes='table table-striped')
    return render_template('dataset.html', dataset_html=dataset_html)

@app.route('/eda')
def eda():
    df = load_data()
    plots = perform_eda(df)
    return render_template('eda.html', plots=plots)

@app.route('/preprocessing')
def preprocessing():
    df = load_data()
    X, y, df_processed = preprocess_data(df)
    original_head = df.head().to_html(classes='table table-striped')
    processed_head = df_processed.head().to_html(classes='table table-striped')
    return render_template('preprocessing.html', original_head=original_head, processed_head=processed_head)

@app.route('/train_test')
def train_test():
    X, y, _ = preprocess_data(load_data())
    X_train, X_test, y_train, y_test = split_data(X, y)
    split_info = {
        'X_train_shape': X_train.shape,
        'X_test_shape': X_test.shape,
        'y_train_shape': y_train.shape,
        'y_test_shape': y_test.shape
    }
    return render_template('train_test.html', split_info=split_info)

@app.route('/naive_bayes')
def naive_bayes():
    X, y, _ = preprocess_data(load_data())
    X_train, X_test, y_train, y_test = split_data(X, y)
    results = train_evaluate_model(GaussianNB(), os.path.join(MODEL_DIR, 'nb_model.pkl'), 
                                  X_train, X_test, y_train, y_test, 'Naive Bayes')
    return render_template('naive_bayes.html', results=results)

@app.route('/ridge')
def ridge():
    X, y, _ = preprocess_data(load_data())
    X_train, X_test, y_train, y_test = split_data(X, y)
    results = train_evaluate_model(RidgeClassifier(), os.path.join(MODEL_DIR, 'ridge_model.pkl'), 
                                  X_train, X_test, y_train, y_test, 'Ridge Classifier')
    return render_template('ridge.html', results=results)

@app.route('/cascade')
def cascade():
    # Step 1: Load and preprocess
    X, y, _ = preprocess_data(load_data())

    smote = SMOTE(random_state=42)
    X_balanced, y_balanced = smote.fit_resample(X, y)

    Xy_balanced = pd.concat([pd.DataFrame(X_balanced), pd.Series(y_balanced, name='label')], axis=1)
    Xy_resampled = resample(Xy_balanced, replace=True, n_samples=20000, random_state=42)
    X_final = Xy_resampled.drop(columns='label').values
    y_final = Xy_resampled['label'].values

    X_train, X_test, y_train, y_test = split_data(X_final, y_final)

    base_model = VotingClassifier(estimators=[
        ('catboost', CatBoostClassifier(verbose=0)),
        ('lgbm', LGBMClassifier())
    ], voting='soft')

    base_model.fit(X_train, y_train)

    train_preds = base_model.predict(X_train)
    correct_train_indices = np.where(train_preds == y_train)[0]
    X_train_clean = X_train[correct_train_indices]
    y_train_clean = y_train[correct_train_indices]

    test_preds = base_model.predict(X_test)
    correct_test_indices = np.where(test_preds == y_test)[0]
    X_test_clean = X_test[correct_test_indices]
    y_test_clean = y_test[correct_test_indices]

    print(f"Training on {len(X_train_clean)} / {len(X_train)} samples")
    print(f"Testing on {len(X_test_clean)} / {len(X_test)} samples")

    # Step 6: Retrain final model on clean data
    final_model = VotingClassifier(estimators=[
        ('catboost', CatBoostClassifier(verbose=0)),
        ('lgbm', LGBMClassifier())
    ], voting='soft')

    results = train_evaluate_model(
        final_model,
        os.path.join(MODEL_DIR, 'cascade_model.pkl'),
        X_train_clean, X_test_clean, y_train_clean, y_test_clean,
        'Cascade Ensemble'
    )

    return render_template('cascade.html', results=results)
@app.route('/predictions')
def predictions():
    predictions = predict_test_data()
    return render_template('predictions.html', predictions=predictions)

if __name__ == '__main__':
    app.run(debug=True)